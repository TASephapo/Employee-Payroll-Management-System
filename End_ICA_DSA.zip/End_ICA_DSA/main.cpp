//END ASSESSMENT PROJECT FOR EXCELLENT ACADEMY PAYROLL

/*
THE PROGRAM IS WRITTEN AND DESIGNED BY:
PROGRAMER : TS'ITSO ABINAR SEPHAPO
STUDENT N0: 1717038
BATCH     : N01
MODULE    : DATA STRUCTURES AND ALGORITHMS(DSA)
LECTURER  : MRS PREMAKAR MONICA

*/

#include <iostream>
#include <iomanip>
#include <conio.h>
#include <limits>
#include <fstream>
#include <string>
#include <ctime>
using namespace std;

//Creating A class called AddEmployee
class AddEmployee{

    private:
    string Catecorytype, EmployeeName, EmployeeDOB,EmployeeAddress;

    string Employeetype,EmployeeContact, Designation;

    int EmployeeID,EmployeeAge, MarkAttendence[30];

    public:
    //Class AddEmployee functions
    void GetEmpData();
    void modify();
    void Display();
    void SearchEmployee();
    void SortEmployee();
    int AdminLogin();
    void CaptureAttendence();
    void PartTimeEmployee();
    void Menu();
    void Delete();
    //void DisplaySearch();


    //Creating pointers of the doubly linked list
    AddEmployee * next;
    AddEmployee * prev;
    AddEmployee * head;


    //Creating A constructor to initizalise variables and pointers
    AddEmployee()
    {

              Catecorytype="TeachingStuff";

              EmployeeName = "Thabo";

              EmployeeID=11111;

              EmployeeAge=26;

              EmployeeDOB="02/05/1997";

              EmployeeAddress="P.O. BOX 100";

              EmployeeContact="56992634";

              Employeetype="FULL-TIME";

              Designation="HOD";

                for(int j=0; j<sizeof(MarkAttendence)/sizeof(MarkAttendence[0]); j++)
                {
                    MarkAttendence[j]=0;
                }


              next = NULL;

              prev = NULL;

              head =NULL;
    }

};//End of the class


//Creating the main menu

void AddEmployee::Menu()
{

    cout<<"  __________________________________________________________________________________________________ "<<endl;
    cout<<" |                                                                                                  |"<<endl;
    cout<<" |                        Excellent Academy School                                                  |"<<endl;
    cout<<" |                        ________________________                                                  |"<<endl;
    cout<<" |\"Aspires to achieve excellence in education & produce self-disciplined educated global citizens \" |"<<endl;
    cout<<" |                                                                                                  |"<<endl;
    cout<<" |.........................................................................................         |"<<endl;
    cout<<" |               Welcome to  Excellent Academy School Employee payroll system                       |"<<endl;
    cout<<" |.........................................................................................         |"<<endl;
    cout<<" |                                     Main Menu                                                    |"<<endl;
    cout<<" |.........................................................................................         |"<<endl;
    cout<<" |       1. Add new employee                                                                        |"<<endl;
    cout<<" |       2. Modify employee details                                                                 |"<<endl;
    cout<<" |       3. Delete employee details                                                                 |"<<endl;
    cout<<" |       4. Capture employee attendance                                                             |"<<endl;
    cout<<" |       5. Calculate and generate salary slip                                                      |"<<endl;
    cout<<" |       6. Search particular employee details                                                      |"<<endl;
    cout<<" |       7. Sort employee details                                                                   |"<<endl;
    cout<<" |          a. Sort by employee ID                                                                  |"<<endl;
    cout<<" |          b. Sort by employee Name                                                                |"<<endl;
    cout<<" |       8.Exit                                                                                     |"<<endl;
    cout<<" |                                                                                                  |"<<endl;
    cout<<" |__________________________________________________________________________________________________|"<<endl;


}//End of the main menu function


/*int AddEmployee::AdminLogin()
{
     cin.clear();

     cout<<"\n************************** Admin Login *****************************";

     string username;
     string password;

     cout<<"\nENTER USERNAME :";
     cin>>username;

     cout<<"\nENTER PASSWORD :";
     cin>>password;

     if(username =="Sephapo" &&  password =="sep")
     {
         cout<<"YOU ARE SUCCESSFULLY LOGGED IN "<<endl;

         AddEmployee obj23;
         obj23.Menu();

    }
     else
     {
         cout<<"INVALID CREDENTIALS PLEASE TRY AGAIN !"<<endl;
     }


}
*/

//A fuction for creating nodes and inserting data inside them

void AddEmployee::GetEmpData()
{
     int option;
     int Catecorytype1;

                int n;

                int count = 1;

                cout<<"\n\n ENTER NUMBER OF EMPLOYEES  :";

                cin>>n;

            while( n > 0)
            {

                    cout<<"\n ENTER INFOMATION FOR EMPLOYEE [ " <<count<<" ] " <<endl;

                    AddEmployee * newnode = new AddEmployee();



                    cout<<"*************************************"<<endl;
                    cout<<"         1. TEACHING STUFF "<<endl;
                    cout<<"         2. SUPPORT  STUFF "<<endl;
                    cout<<"         3. MANAGEMENT      "<<endl;
                    cout<<"*************************************"<<endl;


                    cout<<"\n CHOOSE CATECORY TYPE FROM ABOVE MENU :"<<endl;

                     cin>>Catecorytype1;



                    if(Catecorytype1 == 1)
                    {

                                cout<<"\nENTER EMPLOYEE NAME                          :";

                                cin>>newnode->EmployeeName;

                                cout<<"\nENTER EMPLOYEE ID                            :";

                                cin>>newnode->EmployeeID;

                            while(1)
                            {

                              if(cin.fail())
                              {
                                cin.clear();
                                cin.ignore(numeric_limits<streamsize>::max(),'\n');

                                cout<<"ONLY NUMBERS ARE ALLOWED PLEASE TRY AGAIN "<<endl;

                                cout<<"\nENTER EMPLOYEE ID                            :";

                                cin>>newnode->EmployeeID;
                              }

                              if(!cin.fail())
                                break;
                            }
                                cout<<"\nENTER EMPLOYEE AGE                           :";
                                cin>>newnode->EmployeeAge;

                            while(1)
                            {
                              if(cin.fail())
                              {
                                cin.clear();

                                cin.ignore(numeric_limits<streamsize>::max(),'\n');

                                cout<<"ONLY NUMBERS ARE ALLOWED PLEASE TRY AGAIN "<<endl;

                                cout<<"\nENTER EMPLOYEE AGE                           :";

                                cin>>newnode->EmployeeAge;
                              }
                              if(!cin.fail())
                                break;
                            }
                                cout<<"\nENTER EMPLOYEE DATE OF BIRTH [DD-MM-YYYY]    :";

                                cin>>newnode->EmployeeDOB;

                                cout<<"\nENTER EMPLOYEE ADDRESS                       :";

                                cin>>newnode->EmployeeAddress;

                                cout<<"\nENTER EMPLOYEE CONTACT                       :";

                                cin>>newnode->EmployeeContact;

                                cout<<"\nENTER EMPLOYEE TYPE: FULL-TIME OR PART-TIME  :";
                                cin>>newnode->Employeetype;

                            if((newnode->Employeetype == "FULL-TIME") || (newnode->Employeetype == "PART-TIME"))
                            {
                                   cout<<"EMPLOYEE TYPE IS SUCCESSFULLY INSERTED "<<endl;

                            }
                            else
                            {
                                    cout<<"\nENTER EMPLOYEE TYPE: FULL-TIME OR PART-TIME  :";
                                    cin>>newnode->Employeetype;
                            }

                                    cout<<"\nENTER EMPLOYEE DESIGNATION                   :";

                                    cin>>newnode->Designation;

                             }
                        if(Catecorytype1 == 2)
                        {

                                cout<<"\nENTER EMPLOYEE NAME                          :";

                                cin>>newnode->EmployeeName;

                                cout<<"\nENTER EMPLOYEE ID                            :";

                                cin>>newnode->EmployeeID;

                            while(1)
                            {

                               if(cin.fail())
                              {
                                cin.clear();
                                cin.ignore(numeric_limits<streamsize>::max(),'\n');

                                cout<<"ONLY NUMBERS ARE ALLOWED PLEASE TRY AGAIN "<<endl;

                                cout<<"\nENTER EMPLOYEE ID                            :";

                                cin>>newnode->EmployeeID;
                              }
                              if(!cin.fail())
                                  break;
                            }
                                cout<<"\nENTER EMPLOYEE AGE                           :";

                                cin>>newnode->EmployeeAge;
                            while(1)
                            {
                              if(cin.fail())
                              {
                                cin.clear();

                                cin.ignore(numeric_limits<streamsize>::max(),'\n');

                                cout<<"ONLY NUMBERS ARE ALLOWED PLEASE TRY AGAIN "<<endl;

                                cout<<"\nENTER EMPLOYEE AGE                           :";

                                cin>>newnode->EmployeeAge;
                              }
                              if(!cin.fail())
                                 break;
                            }
                                cout<<"\nENTER EMPLOYEE DATE OF BIRTH [DD-MM-YYYY]    :";

                                cin>>newnode->EmployeeDOB;

                                cout<<"\nENTER EMPLOYEE ADDRESS                       :";

                                cin>>newnode->EmployeeAddress;

                                cout<<"\nENTER EMPLOYEE CONTACT                       :";

                                cin>>newnode->EmployeeContact;

                                cout<<"\nENTER EMPLOYEE DESIGNATION                   :";

                                cin>>newnode->Designation;


                         }
                        if(Catecorytype1 == 3)
                         {

                                 cout<<"\nENTER EMPLOYEE NAME                         :";

                                 cin>>newnode->EmployeeName;

                                 cout<<"\nENTER EMPLOYEE ID                           :";

                                 cin>>newnode->EmployeeID;

                            while(1)
                            {

                              if(cin.fail())
                              {
                                 cin.clear();
                                 cin.ignore(numeric_limits<streamsize>::max(),'\n');

                                 cout<<"ONLY NUMBERS ARE ALLOWED PLEASE TRY AGAIN "<<endl;

                                 cout<<"\nENTER EMPLOYEE ID                           :";

                                 cin>>newnode->EmployeeID;
                               }
                               if(!cin.fail())
                                    break;
                            }
                                  cout<<"\nENTER EMPLOYEE AGE                         :";
                                  cin>>newnode->EmployeeAge;

                            while(1)
                            {
                               if(cin.fail())
                               {
                                  cin.clear();

                                  cin.ignore(numeric_limits<streamsize>::max(),'\n');

                                  cout<<"ONLY NUMBERS ARE ALLOWED PLEASE TRY AGAIN "<<endl;

                                  cout<<"\nENTER EMPLOYEE AGE                         :";

                                  cin>>newnode->EmployeeAge;
                                }
                                if(!cin.fail())
                                    break;
                             }
                                  cout<<"\nENTER EMPLOYEE DATE OF BIRTH [DD-MM-YYYY]  :";

                                  cin>>newnode->EmployeeDOB;

                                  cout<<"\nENTER EMPLOYEE ADDRESS                     :";

                                  cin>>newnode->EmployeeAddress;

                                  cout<<"\nENTER EMPLOYEE CONTACT                     :";

                                  cin>>newnode->EmployeeContact;

                                  cout<<"\nENTER EMPLOYEE DESIGNATION                 :";

                                  cin>>newnode->Designation;
                           }

                                  newnode->next = NULL;
                                  newnode->prev = NULL;

                            if(   head == NULL   )
                            {
                                  head = newnode; //Creating the head node

                            }
                            else
                            {

                                  AddEmployee * temp = new AddEmployee();
                                  temp = head;

                                  while(temp->next != NULL)
                                  {

                                        temp = temp->next;

                                  }
                                  temp->next=newnode;
                                  newnode->prev = temp;

                            }
                            count++;
                            n--;


      }




}//End of the Function


//Creating the Display function
void AddEmployee::Display()
{




  cout<<"\n*************************************************************************************************\n"<<endl;

  cout<<"\n              FORWARD DISPLAY OF EMPOYEE INFOMATION                                              \n"<<endl;
  cout<<"\n*************************************************************************************************\n"<<endl;

  AddEmployee * temp = new AddEmployee();

  AddEmployee * tail = new AddEmployee();

  temp=head;

  int count1=1;

  while(temp != NULL)
  {
   cout<<"\n\n***************** EMPLOYEE ["<<count1<<"]" <<" INFOMATION **************************************\n" <<endl;


   cout<< "            EMPLOYEE NAME       :" <<  temp->EmployeeName     <<endl;

   cout<< "            EMPLOYEE ID         :" <<  temp->EmployeeID       <<endl;

   cout<< "            EMPLOYEE AGE        :" <<  temp->EmployeeAge      <<endl;

   cout<< "            EMPLOYEE DOB        :" <<  temp->EmployeeDOB      <<endl;

   cout<< "            EMPLOYEE ADDRESS    :" <<  temp->EmployeeAddress  <<endl;

   cout<< "            EMPLOYEE CONTACT    :" <<  temp->EmployeeContact  <<endl;

   cout<< "            EMPLOYEE TYPE       :" <<  temp->Employeetype     <<endl;

   cout<< "           EMPLOYEE DESIGNATION :"  <<  temp->Designation    <<endl;

   if(temp->next == NULL)
   {
     tail=temp;

   }
   temp = temp->next;
   count1++;

 }
cout<<"\n\n************************************************************************************************\n" <<endl;

cout<<endl;
/*

                                         temp=tail;

  cout<<"\n*************************************************************************************************\n"<<endl;

  cout<<"\n                BACKWARD DISPLAY OF EMPOYEE INFOMATION                                              \n"<<endl;
  cout<<"\n*************************************************************************************************\n"<<endl;

  while(temp != NULL)
  {

   cout<< "             EMPLOYEE DESIGNATION :"  <<  temp->Designation     <<endl;

   cout<< "             EMPLOYEE TYPE       :" <<  temp->Employeetype     <<endl;

   cout<< "             EMPLOYEE CONTACT    :" <<  temp->EmployeeContact  <<endl;

   cout<< "             EMPLOYEE ADDRESS    :" <<  temp->EmployeeAddress  <<endl;

   cout<< "             EMPLOYEE AGE        :" <<  temp->EmployeeAge      <<endl;

   cout<< "             EMPLOYEE ID         :" <<  temp->EmployeeID       <<endl;

   cout<< "             EMPLOYEE NAME       :" <<  temp->EmployeeName     <<endl;

   temp=temp->prev;
 }
*/

}//End of the Display function


//Creating the modifying Function
void AddEmployee::modify()
{
    int    EmployeeID;
    int choice;


    do
    {
       cout<<" __________________________________________________________________________________________________ "<<endl;
       cout<<" |>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>|"<<endl;
       cout<<" |                                                                                                  |"<<endl;
       cout<<" |                             MODIFYING EMPLOYEE MENU                                              |"<<endl;
       cout<<" |................................................................................................. |"<<endl;
       cout<<" |       1. Employee Name                                                                           |"<<endl;
       cout<<" |       2. EmployeeAge                                                                             |"<<endl;
       cout<<" |       3. EmployeeDOB                                                                             |"<<endl;
       cout<<" |       4. EmployeeAddress                                                                         |"<<endl;
       cout<<" |       5. EmployeeContact                                                                         |"<<endl;
       cout<<" |       6. Employeetype                                                                            |"<<endl;
       cout<<" |       7. Designation                                                                             |"<<endl;
       cout<<" |       8. Exit                                                                                    |"<<endl;
       cout<<" |                                                                                                  |"<<endl;
       cout<<" |                                                                                                  |"<<endl;
       cout<<" |                                                                                                  |"<<endl;
       cout<<" |__________________________________________________________________________________________________|"<<endl;


       cout<<"\n ENTER THE OPTION FROM THE ABOVE MENU [1-8]"<<endl;
       cin>>choice;

       AddEmployee * temp = new AddEmployee();

       if(choice == 1)
       {
         string New_EmployeeName;

         cout<<" Enter the EmployeeID for name to modify :";

         cin>>EmployeeID;

         cout<<" Enter new Name for EmployeeID "<<EmployeeID <<" : ";

         cin>>New_EmployeeName;

         if(head == NULL)
         {
            cout<<" NO DATA FOUND "<<endl;
         }
         else
         {
             temp = head;

             while(temp->EmployeeID != EmployeeID )
             {
                temp = temp->next;
             }
             temp->EmployeeName = New_EmployeeName ;

             cout<<"\nEmployee name succefully modified"<<endl;

         }
         Display();

      }

      if(choice == 2)
      {
        int    New_EmployeeAge;
        cout<<" Enter the EmployeeID for name to modify :";
        cin>>EmployeeID;

        cout<<" Enter new Age for EmployeeID "<<EmployeeID <<" : ";
        cin>>New_EmployeeAge;

        if(head == NULL)
        {
            cout<<" NO DATA FOUND "<<endl;
        }
        else
        {
            temp = head;
            while(temp->EmployeeID != EmployeeID )
            {
                temp = temp->next;

            }
            temp->EmployeeAge = New_EmployeeAge;

            cout<<"Employee Age succefully modified"<<endl;

         }
         Display();

      }
      if(choice == 3)
      {
        string New_EmployeeDOB;

        cout<<" Enter the EmployeeID for Employee date of birth to modify :";

        cin>>EmployeeID;

        cout<<" Enter new date of birth for EmployeeID "<<EmployeeID <<" : ";
        cin>>New_EmployeeDOB;

        if(head == NULL)
        {
          cout<<" NO DATA FOUND "<<endl;
        }
        else
        {
            temp = head;
            while(temp->EmployeeID != EmployeeID )
            {
                temp = temp->next;
            }
            temp->EmployeeDOB = New_EmployeeDOB;

            cout<<"Employee name succefully modified"<<endl;
        }
        Display();
    }
    if(choice == 4)
    {
        string New_EmployeeAddress;

        cout<<" Enter the EmployeeID for the Address to modify :";
        cin>>EmployeeID;

        cout<<" Enter new Employee Address for EmployeeID no :"<<EmployeeID <<" : ";
        cin>>New_EmployeeAddress;

        if(head == NULL)
        {
            cout<<" NO DATA FOUND "<<endl;
        }
        else
        {
            temp = head;
            while(temp->EmployeeID != EmployeeID )
            {
                temp = temp->next;
            }
            temp->EmployeeAddress = New_EmployeeAddress;
            cout<<"\nEmployee name succefully modified"<<endl;


        }
        Display();


    }
    if(choice == 5)
    {
        string New_EmployeeContact;

        cout<<" Enter the EmployeeID for the Phone Number to modify :";

        cin>>EmployeeID;

        cout<<" Enter new Employee Phone Number for EmployeeID no :"<<EmployeeID <<" : ";
        cin>>New_EmployeeContact;;

        if(head == NULL)
        {
          cout<<" NO DATA FOUND "<<endl;
        }
        else
        {
            temp = head;
            while(temp->EmployeeID != EmployeeID )
            {
                temp = temp->next;
            }
            temp->EmployeeContact = New_EmployeeContact;

            cout<<"Employee Contact number is succefully modified"<<endl;

        }
        Display();
    }
    if(choice == 6)
    {
        string New_Employeetype;

        cout<<" Enter the EmployeeID for the Phone Number to modify :";

        cin>>EmployeeID;

        cout<<" Enter new Employee type for EmployeeID no :"<<EmployeeID <<" : ";

        cin>>New_Employeetype;

        if(head == NULL)
        {
            cout<<" NO DATA FOUND "<<endl;
        }
        else
        {
            temp = head;
            while(temp->EmployeeID != EmployeeID )
            {
                temp = temp->next;
            }
            temp->Employeetype = New_Employeetype;
            cout<<"Employee type is succefully modified"<<endl;
        }
        Display();
    }
    if(choice ==7 )
    {
        string NewDesignation;

        cout<<" Enter the EmployeeID for the Phone Number to modify :";

        cin>>EmployeeID;

        cout<<" Enter new Employee Designation for EmployeeID no :"<<EmployeeID <<" : ";

        cin>>NewDesignation;;

        if(head == NULL)
        {
          cout<<" NO DATA FOUND "<<endl;
        }
        else
        {
            temp = head;
            while(temp->EmployeeID != EmployeeID )
            {
                temp = temp->next;
            }
            temp->Designation = NewDesignation;

            cout<<"\nEmployee Designation is succefully modified"<<endl;
        }


    }

    if(choice == 8)
    {
        break;
        Menu();
    }

  }while(choice == 1 || choice == 2 || choice == 3 || choice == 4 || choice == 5 || choice == 6 || choice==7 || choice == 8);

}//End of Modifying Function



//Creating the Search function
void AddEmployee::SearchEmployee()
{
    int Emp1;

    if(head == NULL)
    {
        cout<<"list underflow"<<endl;
    }
    else
    {
        int EmployeeID;

        AddEmployee *temp = NULL;

        AddEmployee *temp1 = NULL;

        cout<<"\nENTER EMPLOYEE ID TO SEARCH IN THE LIST: ";

        cin>>Emp1;

        temp1 = head;

        temp = head;

        while(temp->EmployeeID != Emp1)
        {
             temp = temp1;
             temp1 = temp1->next;
        }



        int count1 = 1;
        cout<<"\n\n***************** EMPLOYEE ["<<count1<<"]" <<" INFOMATION **************************************\n" <<endl;


           cout<< "            EMPLOYEE NAME       :" <<  temp->EmployeeName     <<endl;

           cout<< "            EMPLOYEE ID         :" <<  temp->EmployeeID       <<endl;

           cout<< "            EMPLOYEE AGE        :" <<  temp->EmployeeAge      <<endl;

           cout<< "            EMPLOYEE ADDRESS    :" <<  temp->EmployeeAddress  <<endl;

           cout<< "            EMPLOYEE CONTACT    :" <<  temp->EmployeeContact  <<endl;

           cout<< "            EMPLOYEE TYPE       :" <<  temp->Employeetype     <<endl;

           cout<< "            EMPLOYEE DESIGNATION :" << temp->Designation    <<endl;

           cout<<"Employee with ID no " <<  Emp1  << " is found "<<endl;






      }
      cout<<"EMPLOYEE WITH ID NO "<< Emp1 <<"IS NOT FOUND "<<endl;





}//End of the Search Function()

void AddEmployee::SortEmployee()
{

    int option1;

    cout<<"************************************************************************"<<endl;
    cout<<"|                      SORT EMPLOYEES                                  |"<<endl;
    cout<<"|                                                                      |"<<endl;
    cout<<"|                      1.Sort by Employee ID                           |"<<endl;
    cout<<"|                      2.Sort by Employee Name                         |"<<endl;
    cout<<"|                      3.Exit                                          |"<<endl;
    cout<<"|                                                                      |"<<endl;
    cout<<"************************************************************************"<<endl;

    cout<<"\n******************ENTER OPTION FROM ABOVE MENU*******************"<<endl;
    cin>>option1;


    switch(option1)
    {

        case 1 :
        {

            int swapped, i;
            AddEmployee * ptrl = new AddEmployee();
            AddEmployee * lptl =new AddEmployee();


            lptl = NULL;

            if(head == NULL)
              {
                 cout<<"No Employee Information found"<<endl;
                 Menu();

              }
            do
            {
                swapped = 0;
                ptrl = head;

                while(ptrl->next != lptl)
                {
                    if(ptrl->EmployeeID > ptrl->next->EmployeeID)
                    {
                        swap(ptrl->EmployeeName, ptrl->next->EmployeeName);
                        swap(ptrl->EmployeeID , ptrl->next->EmployeeID);
                        swap(ptrl->EmployeeAge , ptrl->next->EmployeeAge);
                        swap(ptrl->EmployeeDOB , ptrl->next->EmployeeDOB);
                        swap(ptrl->EmployeeAddress, ptrl->next->EmployeeAddress);
                        swap(ptrl->EmployeeContact, ptrl->next->EmployeeContact);
                        swap(ptrl->Employeetype , ptrl->next->Employeetype);
                        swap(ptrl->Designation , ptrl->next->Designation);

                        swapped = 1;
                    }
                    ptrl = ptrl->next;
                }
                lptl = ptrl;

            }while(swapped);

            break;

        }
        case 2 :
        {
            AddEmployee * temp ,*current;




            for(temp =head->next; temp!= NULL; temp=temp->next)
            {
                string Employeename    = temp->EmployeeName;
                int    EmployeeID      = temp->EmployeeID;
                int    EmployeeAge     = temp->EmployeeAge;
                string EmployeeDOB     = temp->EmployeeDOB;
                string EmployeeAddress = temp->EmployeeAddress;
                string Employeetype    = temp->Employeetype;
                string EmployeeContact = temp->EmployeeContact;
                string Designation     = temp->Designation;
                current = temp;

                while(current->prev != NULL && current->prev->EmployeeName >= Employeename)
                {
                    current->EmployeeID       = current->prev->EmployeeID;
                    current->EmployeeAge      = current->prev->EmployeeAge;
                    current->EmployeeName     = current->prev->EmployeeName;
                    current->EmployeeDOB      = current->prev->EmployeeDOB;
                    current->EmployeeAddress  = current->prev->EmployeeAddress;
                    current->Employeetype     = current->prev->Employeetype;
                    current->EmployeeContact  = current->prev->EmployeeContact;
                    current->Designation      = current->prev->Designation;
                    current = current->prev;
                }
                current->EmployeeName       = Employeename;
                current->EmployeeID         = EmployeeID;
                current->EmployeeAge        = EmployeeAge;
                current->EmployeeDOB        = EmployeeDOB;
                current->EmployeeAddress    = EmployeeAddress;
                current->Employeetype       = Employeetype;
                current->EmployeeContact    = EmployeeContact;
                current->Designation        = Designation;


             }
            Display();
            break;

        }

    }

}


//Function to delete An Employee Infomation
void AddEmployee::Delete()
{

        int del_id;
        cout<<"Enter the Employee id to delete :";
        cin>>del_id;

        if(head == NULL)
        {
            cout<<"The list of employees is empty no Information to remove"<<endl;

        }
        else if(head->next == NULL)
        {
            delete head;
            head = NULL;

            cout<<"\n The last Employee of ID  ["<<del_id <<"] is successfully removed from the system "<<endl;


        }
        else
        {

               if(head->EmployeeID == del_id)
               {
                   AddEmployee * temp2 = new AddEmployee();
                   head = head->next;
                   head->prev = NULL;
                   delete temp2;

                   cout<<"Employee details for ID no [" << del_id <<"] is successfully removed"<<endl;
                   Display();

               }
               else
               {
                        AddEmployee * temp = new AddEmployee();
                        AddEmployee * temp3 = new AddEmployee();
                        temp=head;
                        temp3=head;

                        while(temp->EmployeeID != del_id)
                        {
                            temp3 = temp;
                            temp = temp->next;


                        }

                        temp3->next = temp->next;
                        temp->next = NULL;
                        delete temp;
                        cout<<"\nEmployee is removed successfully from the system"<<endl;
                        Display();

                 }


            }


    }





void AddEmployee::CaptureAttendence()
{

    int choice;
    int res;

    cout<<"*************CAPTURE EMPLOYEE ATTENDANCE*************"<<endl;
    int Emp1;





        if(head == NULL)
        {
            cout<<"list underflow"<<endl;
        }

        else
        {

                 do
                {


                    int EmployeeID;

                    AddEmployee *temp = NULL;

                    AddEmployee *temp1 = NULL;

                    cout<<"\nENTER EMPLOYEE ID TO SEARCH IN THE LIST: ";

                    cin>>Emp1;

                    temp1 = head;

                    temp = head;

                    while(temp->EmployeeID != Emp1)
                    {
                         temp = temp1;
                         temp1 = temp1->next;
                    }
                    if(temp->EmployeeID != Emp1)
                    {
                        cout<<"EMPLOYEE ID BEING SEARCHED IS NOT FOUND "<<endl;
                    }
                    else
                    {
                        int day, clockinTime, clockouTime, worked_hours;
                        int flag = 0;
                        cout<<" ENTER THE CURRENT DAY[1-30] :"<<endl;
                        cin>>day;

                        cout<<"ENTER CLOCK IN TIME[12hr] FOR EMPLOYEE ID ["<<temp->EmployeeID<<"] ON DAY ["<<day<<"] :";
                        cin>>clockinTime;

                        cout<<"ENTER CLOCK OUT TIME[24hr] FOR EMPLOYEE ID ["<<temp->EmployeeID<<"] :";
                        cin>>clockouTime;

                        worked_hours = clockouTime - clockinTime;

                        temp->MarkAttendence[day] = worked_hours;

                        cout<<"WORKED HOURS FOR DAY ["<< day <<"] ="<<worked_hours<<endl;

                        int response;

                        cout<<"DO YOU WANT TO VIEW EMPLOYEE ATTENDENCE ? PRESS 1"<<endl;
                        cin>>response;

                        if(response == 1)
                        {
                            for(int i=0; i<sizeof(temp->MarkAttendence)/sizeof(temp->MarkAttendence[0]); i++)
                            {


                                cout<<" DAY["<<i+1<< "] : "<<temp->MarkAttendence[i+1]<<"hrs" <<endl;

                            }
                        }
                    }
                    cout<<"DO YOU WANT TO CAPTURE ATTENDENCE AGAIN ? [Y = YES , N = NO ]"<<endl;
                    cin>>res;


                }while(res == 1);

    }




}


void AddEmployee::PartTimeEmployee()
{

        cout<<"*************************************************************************"<<endl;
        cout<<"                       GENERATE SLIP FOR EMPLOYEE                        "<<endl;
        cout<<"                                                                         "<<endl;
        cout<<"                 1. GENARATE SLIP FOR PARTTIME EMPLOYEE                  "<<endl;
        cout<<"                 2. GENERATE SLIP FOR FULLTIME EMPLOYEE                  "<<endl;
        cout<<"                                                                         "<<endl;
        cout<<"*************************************************************************"<<endl;


             cout<<"****************SELECT CHOICE FROM ABOVE MENU****************"<<endl;
             int choice;

             cin>>choice;
             char ch1='Y';
             time_t t = time(NULL);
             tm* timePtr = localtime(&t);


             switch(choice)
             {
                 case 1:
                {

                            int employeeid;

                            cout<<" Enter Employee Id to search from the system :";
                            cin>>employeeid;

                            AddEmployee * temp = new AddEmployee();

                            AddEmployee * temp1=new AddEmployee();

                            temp = head;

                            temp1->next = NULL;

                            while(temp->next != head && temp1->next != head )
                            {
                                if(temp->EmployeeID == employeeid)
                                {
                                    temp1->next = head;

                                }
                                else
                                {
                                    temp = temp->next;

                                }
                                if(temp->EmployeeID == employeeid && temp->Employeetype == "PART-TIME")
                                {
                                     float Pay = 300;
                                     float deduction =0;
                                     int hrs =0;
                                     float Net =0;

                                     for(int i=0; i<sizeof(temp->MarkAttendence)/sizeof(temp->MarkAttendence[0]); i++)
                                     {
                                         hrs = hrs + temp->MarkAttendence[i];
                                     }

                                     Net = ((Pay* hrs) - deduction);

                                     temp1 = head;

                                     while(temp1 != NULL)
                                     {

                                            if(temp1->Employeetype =="PART-TIME")
                                            {

                                                cout<<"\t _____________________________________________________________________________________________________________________"<<endl;
                                                cout<<"\t|                                        Execellent Academy School                                                    |"<<endl;
                                                cout<<"\t|                                            Salary Slip                                                              |"<<endl;
                                                cout<<"\t|                                                                                                                     |"<<endl;
                                                cout<<"\t|                                                                                                                     |"<<endl;
                                                cout<<"\t| Employee Name :"<<setw(10)<<temp1->EmployeeName<<setw(92)<<"                                                        |"<<endl;
                                                cout<<"\t| Designation   :"<<setw(10)<<temp1->Designation<<setw(92)<<"                                                         |"<<endl;
                                                cout<<"\t| Month and Year:"<<setw(10)<<(timePtr->tm_mon)+1<<" "<<(timePtr->tm_year)+1900<<setw(87)<<"                          |"<<endl;
                                                cout<<"\t| ___________________________________________________________________________________________________________________ |"<<endl;
                                                cout<<"\t||                                             Earnings                                                              ||"<<endl;
                                                cout<<"\t||___________________________________________________________________________________________________________________||"<<endl;
                                                cout<<"\t|| Number of In the |"<<setw(10)<<hrs<<"hours"<<setw(83)<<"   |Payment Per hour                         |M300.00     ||"<<endl;
                                                cout<<"\t|| Month Of April   |                                         |                                         |            ||"<<endl;
                                                cout<<"\t||__________________|_________________________________________|________________________________________ |____________||"<<endl;
                                                cout<<"\t|| Total Addition   |"<<setw(10)<<"M"<<Net<<".00"<<setw(81)<<"|Total Deduction                          |  0         ||"<<endl;
                                                cout<<"\t||__________________|_________________________________________|_________________________________________|____________||"<<endl;
                                                cout<<"\t||                  | Net Salary                              |"<<setw(5)<<"M"<<Net<<".00"<<setw(44)<<" |            ||"<<endl;
                                                cout<<"\t||__________________|_________________________________________|_________________________________________|____________||"<<endl;
                                                cout<<"\t|                                                                                                                     |"<<endl;
                                                cout<<"\t|                                                                                                                     |"<<endl;
                                                cout<<"\t|Signature of Employee:___________________                  Principal/Director Sign:___________                       |"<<endl;
                                                cout<<"\t|                                                                                                                     |"<<endl;
                                                cout<<"\t|                 Date:___________________                                     Date:____________                      |"<<endl;
                                                cout<<"\t|                                                                                                                     |"<<endl;
                                                cout<<"\t|_____________________________________________________________________________________________________________________|"<<endl;
                                            }
                                                temp1 = temp1->next;


                                        }
                                }
                                else
                                {
                                    cout<<" Employee with ID  "<<temp->EmployeeID <<"is not partime employee"<<endl;
                                    Menu();
                               }


                                }
                                 break;
                            }
                            case 2:
                               {



                                                int employeeid;

                                                cout<<" Enter Employee Id to search from the system :";
                                                cin>>employeeid;

                                                AddEmployee * temp = new AddEmployee();

                                                AddEmployee * temp1=new AddEmployee();

                                                temp = head;

                                                temp1->next = NULL;

                                                while(temp->next != head && temp1->next != head )
                                                {
                                                    if(temp->EmployeeID == employeeid)
                                                    {
                                                        temp1->next = head;

                                                    }
                                                    else
                                                    {
                                                        temp = temp->next;

                                                    }
                                                }
                                                if(temp->EmployeeID == employeeid && temp->Employeetype =="FULL-TIME")
                                                {
                                                    int totalHours = 240;
                                                    float CA = 1500.00;
                                                    float MI = 2000;
                                                    int day;
                                                    int hr =0;
                                                    int dayloss=0;
                                                    float Rate;
                                                    float regular;
                                                    float overtim;
                                                    int losshr;
                                                    float Payloss=0;
                                                    int overhr=0;
                                                    float pay=0;
                                                    float HRA;
                                                    float PF;
                                                    float tax =0;
                                                    float add =0;

                                                    cout<<"Enter Hourly Rate for Overtime :";
                                                    cin>>Rate;

                                                    for(int i=0; i<sizeof(temp->MarkAttendence)/sizeof(temp->MarkAttendence[0]); i++)
                                                    {

                                                        hr = hr + temp->MarkAttendence[i];

                                                        if(temp->MarkAttendence[i] != '\0')
                                                        {
                                                            day = day + i;
                                                        }
                                                        dayloss = 30 - day;

                                                        if(hr <= totalHours)
                                                        {
                                                            regular = hr * Rate;

                                                            overtim = 0;
                                                        }
                                                        else
                                                        {
                                                          regular = totalHours * Rate;

                                                          overtim =((hr - totalHours) * Rate * 1.5);
                                                        }

                                                        if(hr < totalHours)
                                                        {
                                                            losshr = totalHours - hr;

                                                            Payloss = losshr * Rate;

                                                            overhr =0;
                                                        }
                                                        else
                                                        {
                                                            overhr = hr -totalHours;
                                                        }

                                                        // pay = regular + overtime;
                                                         //HRA = 10/100*(pay);
                                                        // PF =  12/100*(pay);

                                                         add = pay + CA + overtim + HRA;


                                                         if(pay >= 300000  && pay < 500000)
                                                         {
                                                             tax = 5/100*(pay);
                                                         }
                                                         else if(pay >= 500000  && pay < 700000)
                                                         {
                                                             tax = 10/100 * (pay);
                                                         }
                                                         else if (pay >=700000 && pay < 1000000)
                                                         {
                                                             tax = 15/100 *(pay);
                                                         }
                                                         else if (pay >=1000000 && pay < 1250000 )
                                                         {
                                                             tax = 20/100*(pay);
                                                         }
                                                         else if (pay >= 1250000 && pay < 1500000)
                                                         {
                                                             tax = 25/100 * (pay);
                                                         }
                                                         else
                                                         {
                                                             tax = 30/100 * (pay);
                                                         }
                                                    float ded = MI+tax +PF;
                                                    float Net = add - ded;

                                                    }

                                            AddEmployee * temp2 = new AddEmployee();
                                            temp2 = head;

                                            while(temp2 != NULL )
                                            {
                                                if(temp2->Employeetype == "FULL-TIME")
                                                {


                                                    cout<<"\t ______________________________________________________________________________________________________________________________________\t"<<endl;
                                                    cout<<"\t|                                                                                                                                      |"<<endl;
                                                    cout<<"\t|                                           Excellent Academy School                                                                   |"<<endl;
                                                    cout<<"\t|                                               Salary Slip                                                                            |"<<endl;
                                                    cout<<"\t|                                                                                                                                      |"<<endl;
                                                    cout<<"\t| Employee Name  :"<<setw(10)<<temp1->EmployeeName<<setw(108) <<"                                                                      |"<<endl;
                                                    cout<<"\t| Designation    :"<<setw(10)<<temp1->Designation<<setw(108) <<"                                                                       |"<<endl;
                                                    cout<<"\t| Month and Year :"<<setw(10)<<(timePtr->tm_mon)+1<<" "<<(timePtr->tm_year)+1900<<setw(103)<<"                                         |"<<endl;
                                                    cout<<"\t| ____________________________________________________________________________________________________________________________________ |"<<endl;
                                                    cout<<"\t||                 Earnings                                |              Deductions                                                  ||"<<endl;
                                                    cout<<"\t||_________________________________________________________|__________________________________________________________________________||"<<endl;
                                                    cout<<"\t|| Basic                |"<<setw(10)<<pay<<setw(101)<<"    | Loss of Pay|"<<setw(10)<<day<<setw(90)<<" |                              ||"<<endl;
                                                    cout<<"\t||______________________|__________________________________|____________|______________________________|______________________________||"<<endl;
                                                    cout<<"\t|| HRA 10%              |"<<setw(10)<<PF<<setw(101)<<"     | Medical Insurance                         |     M2000.00                 ||"<<endl;
                                                    cout<<"\t||______________________|__________________________________|___________________________________________|______________________________||"<<endl;
                                                    cout<<"\t|| Conveyance allowance | "<<setw(10)<<CA<<setw(101)<<"    | Provident Fund 12%                        |"<<PF << "                    ||"<<endl;
                                                    cout<<"\t||______________________|__________________________________|___________________________________________|______________________________||"<<endl;
                                                    cout<<"\t|| Overtime|"<<overhr<<"|"<<setw(10)<<overtim<<setw(101)<<"| Income Tax                                |"<<tax<<"                     ||"<<endl;
                                                    cout<<"\t||_________|____________|__________________________________|___________________________________________|______________________________||"<<endl;
                                                    cout<<"\t|| Total Addition       |"<<setw(10)<<add<<setw(101)<<"    | Total Deduction                           |"<<"                        ||"<<endl;
                                                    cout<<"\t||______________________|__________________________________|___________________________________________|______________________________||"<<endl;
                                                    cout<<"\t||                      |  Net Salary                      |"<<setw(10)<<add<<setw(101)<<"             |                              ||"<<endl;
                                                    cout<<"\t||______________________|__________________________________|___________________________________________|______________________________||"<<endl;
                                                    cout<<"\t|                                                                                                                                      |"<<endl;
                                                    cout<<"\t|                                                                                                                                      |"<<endl;
                                                    cout<<"\t| Signature of Employee:______________                     Principal/Director:___________________                                      |"<<endl;
                                                    cout<<"\t|                 Date :______________                                 Date  :___________________                                      |"<<endl;
                                                    cout<<"\t|                                                                                                                                      |"<<endl;
                                                    cout<<"\t|______________________________________________________________________________________________________________________________________|"<<endl;

                                                 }
                                                 temp2 = temp2->next;

                                            }
                                        }
                                        else
                                        {
                                                cout<<" Employee with ID  "<<temp->EmployeeID <<"is not partime employee"<<endl;
                                                Menu();
                                        }
                                        break;
                                    }

                             }


         //cout<<"\n Do you want to continue? type Y or N \n";
         //cin>>ch1;


}









int main()
{
    int choice;
    AddEmployee obj;
    char ch1='Y';




  while (ch1=='Y'||ch1=='y')
  {

       obj.Menu();

       cout<<"\n\nENTER THE OPTION FROM ABOVE MENU [1-8]" <<endl;

       cin>>choice;

       while(1)
     {
         if(cin.fail())
         {
             cin.clear();

             cin.ignore(numeric_limits<streamsize>::max(),'\n');

             cout<<"\n ENTER THE OPTION FROM ABOVE MENU [1-8]" <<endl;

             cin>>choice;
         }
         if(!cin.fail())
            break;
     }

       switch(choice)
      {
         case 1:
        {

            obj.GetEmpData();
            obj.Display();
            break;
        }

        case 2:
        {
            obj.modify();
            break;
        }
        case 3:
        {
            obj.Delete();
            break;
        }
        case 4:
        {
            obj.CaptureAttendence();

            break;
        }
        case 6:
        {
            obj.SearchEmployee();

            break;
        }
        case 5:
        {
            obj.PartTimeEmployee();
            break;
        }
        case 7:
        {
            obj.SortEmployee();
            obj.Display();

            break;

        }
        case 8:
        {
          break;
        }
        default :
        {
            cout<<"\nEnter Y or N only "<<endl;
            break;
        }


      }
      cout<<"\n Do you want to continue? type Y or N \n";
      cin>>ch1;

 }

        return 0;
}
