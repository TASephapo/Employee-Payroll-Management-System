#include <iostream>
using namespace std;

int g_c_d(int x, int y);

/*




*/

int main()
{
    int x , y;

    cout<<"Enter First Positive  Interger Number :";
    cin>> x;

    cout<<"Enter Second Interger Number : ";
    cin>>y;

    int results = g_c_d(x,y);

    cout<<"The highest common diviser of " << x << " & "  << y <<" is : " <<  results;


    return 0;
}

int g_c_d(int x, int y)
{
    if ((x <= 0) || (y <= 0))
    {
        return 0;
    }
    while( x != y)
    {
        if(x > y)
        {
            x = x-y;
        }
        else
        {
            y = y - x;
        }
    }
    return x;
}
